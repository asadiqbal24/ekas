<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<style>
    .error {
        color: red;
        display: none;
    }

    .invalid {
        border: 2px solid red;
    }
    .flatpickr-calendar{
        background-color: var(--primary-color) !important;
    }
    .iti {
        width:100%!important;
    }
</style>
<link rel="profile" href="https://gmpg.org/xfn/11">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/main-style.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Poppins:wght@100;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<section class="oks-signup-form">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-5 col-lg-5 col-md-8 m-auto">
                    <div class="sign-up-progressbar">
                        <div class="sign-up-heading oks-book-time-heading">
                            <h3>Book Consultancy Form</h3>
                        </div>
                        <ul id="book-progressbar">
                            <li class="active">Services<span></span></li>
                            <li>Time & Date<span></span></li>
                            <li>Payment<span></span></li>
                        </ul>
                    </div>
                    <div class="oks-book-consultent-wrap">
                        <script src='https://js.stripe.com/v2/' type='text/javascript'></script>
        <form role="form" action="{{route('stripePost')}}" method="post" class="require-validation" data-cc-on-file="false" data-stripe-publishable-key="{{ env('pk_test_51Owfu5HDyUEvV9bCayz668CJCAwcNZjlHeXi36IFKL5b8bfuJTaaH0IbjQ91u9SXsXQQiOvjwryzDji77CTYycY900ZTXAEwYK') }}" id="payment-form">
            @csrf
                            <div class="form-step" id="step1">
                                <div class="form-group">
                                    <label for="guidance_form">Choose Services</label>
                                    <select id="guidance_form" class="form-control" required name="service">
                                        <option value="" disabled selected>-- Select Services --</option>
                                        <option value="academic">Application Guidance</option>
                                        <option value="academic">Academic Guidance</option>
                                        <option value="visa">Visa Guidance</option>
                                        <option value="general">General Guidance</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="guidance_package">Choose Guidance Package</label>
                                    <select id="guidance_package" class="form-control" required name="package">
                                    <option value="" disabled selected>-- Select Guidance Package --</option>
                                    <option value="single">Single Session - 30€</option>
                                    <option value="bundle1">Bundle One - 50€</option>
                                    <option value="bundle2">Bundle Two - 100€</option>
                                </select>
                                </div>
                                <div class="book-buttons">
                                    <button type="button" class="next-btn" id="next-btn-step1" disabled>Next</button>
                                </div>
                            </div>
        <div class="form-step" id="step2" style="display: none;">
    <div class="form-group">
        <label for="selected_date">Select Date</label>
        <input type="text" id="selected_date" class="form-control" required name="date">
    </div>
    <div class="form-group">
        <label for="selected_time">Select Time</label>
        <input type="text" id="selected_time" class="form-control" required name="time">
    </div>
    <div class="book-buttons">
        <button type="button" class="previous-btn">Previous</button>
        <button type="button" class="next-btn" id="next-btn-step2">Next</button>
    </div>
</div>

<div class="form-step" id="step3" style="display: none;">
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" class="form-control" placeholder="Enter Email here" required name="email">
        <span id="email-error" class="error">Email is required</span>
    </div>
    <div class="form-group">
        <label for="phone">Phone</label>
        <input type="number" id="phone" class="form-control" placeholder="Enter Phone here" required name="phone_no">
        <span id="phone-error" class="error">Phone number is required</span>
    </div>
    <!-- Stripe Card Form -->
    <div class="row mt-3" id="stripe-card-form">
        <input type="hidden" name="student_id">
        <div class="form-group">
            <label for="username">
                <h6>Card Owner</h6>
            </label>
            <input type="text" name="username" placeholder="Card Owner Name" required class="form-control" />
        </div>
        <div class="form-group">
            <label for="cardNumber">
                <h6>Card number</h6>
            </label>
            <div class="input-group">
                <input type="text" name="cardNumber" placeholder="Valid card number" class="form-control card-number" size='20' autocomplete='off' required />
                <div class=" mt-5 input-group-append">
                    <span class="input-group-text text-muted"> <i class="fab fa-cc-visa mx-1"></i> <i class="fab fa-cc-mastercard mx-1"></i> <i class="fab fa-cc-amex mx-1"></i> </span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-8">
                <div class="form-group">
                    <label>
                        <span class="hidden-xs">
                            <h6>Expiration Date</h6>
                        </span>
                    </label>
                    <div class="input-group">
                        <input type="number" placeholder="MM" name="card-expiry-month" class="form-control card-expiry-month" required size='2'>
                        <input type="number" placeholder="YY" name="card-expiry-year" class="form-control card-expiry-year" required size='2'>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group mb-4">
                    <label data-toggle="tooltip" title="Three digit CV code on the back of your card">
                        <h6>CVV <i class="fa fa-question-circle d-inline"></i></h6>
                    </label>
                    <input type="text" autocomplete='off' required class="form-control card-cvc" size='4'>
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" style="background:black; width: 100%;" class="subscribe btn btn-primary btn-block shadow-sm book-buttons">Confirm Payment</button>
        </div>
    </div>
    <!-- End of Stripe Card Form -->
    <!-- <div class="book-buttons">
        <button type="button" class="previous-btn">Previous</button>
    </div> -->
</div>

 </div>
 </div>
</div>
      <!-- <div class="row mt-3" id="stripe-card-form" style="display: none;">

         
                            
                            <input type="hidden"  name="student_id">
                            <div class="form-group">
                                <label for="username">
                                    <h6>Card Owner</h6>
                                </label>
                                <input type="text" name="username" placeholder="Card Owner Name" required class="form-control" />
                            </div>
                            <div class="form-group">
                                <label for="cardNumber">
                                    <h6>Card number</h6>
                                </label>
                                <div class="input-group">
                                <input type="text" name="cardNumber" placeholder="Valid card number" class="form-control card-number" size='20' autocomplete='off' required />
                                    <div class=" mt-5 input-group-append">
                                        <span class="input-group-text text-muted"> <i class="fab fa-cc-visa mx-1"></i> <i class="fab fa-cc-mastercard mx-1"></i> <i class="fab fa-cc-amex mx-1"></i> </span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <label>
                                            <span class="hidden-xs">
                                                <h6>Expiration Date</h6>
                                            </span>
                                        </label>
                                        <div class="input-group">
                                        <input type="number" placeholder="MM" name="card-expiry-month" class="form-control card-expiry-month" required size='2'>
                                        <input type="number" placeholder="YY" name="card-expiry-year" class="form-control card-expiry-year" required size='2'>

                                 </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group mb-4">
                                        <label data-toggle="tooltip" title="Three digit CV code on the back of your card">
                                            <h6>CVV <i class="fa fa-question-circle d-inline"></i></h6>
                                        </label>
                                        <input type="text" autocomplete='off' required class="form-control card-cvc" size='4'>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="subscribe btn btn-primary btn-block shadow-sm">Confirm Payment</button></div>
                        </form>
        @if ((Session::has('success-message')))
        <div class="alert alert-success col-md-12">{{
          Session::get('success-message') }}</div>
        @endif @if ((Session::has('fail-message')))
        <div class="alert alert-danger col-md-12">{{
          Session::get('fail-message') }}</div>
        @endif
    </div> -->


        </div>
    </section>

<script type="text/javascript">
    $(function() {
      var $form = $(".require-validation");
      $('form.require-validation').bind('submit', function(e) {
        var $form = $(".require-validation"),
        inputSelector = ['input[type=email]', 'input[type=password]', 'input[type=text]', 'input[type=file]', 'textarea'].join(', '),
        $inputs = $form.find('.required').find(inputSelector),
        $errorMessage = $form.find('div.error'),
        valid = true;
        $errorMessage.addClass('hide');
        $('.has-error').removeClass('has-error');
        $inputs.each(function(i, el) {
            var $input = $(el);
            if ($input.val() === '') {
                $input.parent().addClass('has-error');
                $errorMessage.removeClass('hide');
                e.preventDefault();
            }
        });
        if (!$form.data('cc-on-file')) {
          e.preventDefault();
          Stripe.setPublishableKey('pk_test_51Owfu5HDyUEvV9bCayz668CJCAwcNZjlHeXi36IFKL5b8bfuJTaaH0IbjQ91u9SXsXQQiOvjwryzDji77CTYycY900ZTXAEwYK');

          // Capture the expiration month input
          var expMonth = $('.card-expiry-month').val();

          Stripe.createToken({
              number: $('.card-number').val(),
              cvc: $('.card-cvc').val(),
              // Pass the expiration month
              exp_month: expMonth,
              exp_year: $('.card-expiry-year').val()
          }, stripeResponseHandler);
        }
      });

    function stripeResponseHandler(status, response) {
        if (response.error) {
            // Log the specific Stripe API error message to the console
            console.error("Stripe API Error:", response.error.message);
            
            // Display the error message to the user
            $('.error')
                .removeClass('hide')
                .find('.alert')
                .text(response.error.message);
        } else {
            /* token contains id, last4, and card type */
            var token = response['id'];
            $form.find('input[type=text]').empty();
            $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
            $form.get(0).submit();
        }
    }

    });

    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr("#selected_date", {
                dateFormat: "Y-m-d",
            });

            flatpickr("#selected_time", {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true
            });
        });
    </script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var paymentMethodSelect = document.getElementById('payment_method');
        var stripeCardForm = document.getElementById('stripe-card-form');

        paymentMethodSelect.addEventListener('change', function () {
            var selectedOption = paymentMethodSelect.value;

            if (selectedOption === 'credit_card') {
                stripeCardForm.style.display = 'block';
            } else {
                stripeCardForm.style.display = 'none';
            }
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var input = document.querySelector("#phone");
        var iti = window.intlTelInput(input, {
            separateDialCode: true,
            preferredCountries: ["us", "gb", "pk", "in"], // Add your preferred countries
            utilsScript: "https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/js/utils.js" // for formatting/validation etc.
        });

        // Example of handling form submission
        $("form").on("submit", function(e) {
            var phoneError = $('#phone-error');
            if (input.value.trim() === "") {
                phoneError.show();
                e.preventDefault();
            } else {
                phoneError.hide();
            }
        });
    });
</script>
<script>

document.addEventListener('DOMContentLoaded', function () {
    // Initialize Flatpickr
    flatpickr("#selected_date", {
        dateFormat: "Y-m-d",
    });

    flatpickr("#selected_time", {
        enableTime: true,
        noCalendar: true,
        dateFormat: "H:i",
        time_24hr: true
    });

    // Form step logic
    const form = document.getElementById('consultancyForm');
    const step1 = document.getElementById('step1');
    const step2 = document.getElementById('step2');
    const step3 = document.getElementById('step3');

    const nextBtnStep1 = document.getElementById('next-btn-step1');
    const nextBtnStep2 = document.getElementById('next-btn-step2');

    const guidanceForm = document.getElementById('guidance_form');
    const guidancePackage = document.getElementById('guidance_package');

    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const emailError = document.getElementById('email-error');
    const phoneError = document.getElementById('phone-error');

    function validateStep1() {
        const isValid = guidanceForm.value && guidancePackage.value;
        nextBtnStep1.disabled = !isValid;
    }

    function validateStep3() {
        let isValid = true;
        if (!emailInput.value) {
            emailError.style.display = 'inline';
            isValid = false;
        } else {
            emailError.style.display = 'none';
        }

        if (!phoneInput.value) {
            phoneError.style.display = 'inline';
            isValid = false;
        } else {
            phoneError.style.display = 'none';
        }

        nextBtnStep2.disabled = !isValid;
    }

    guidanceForm.addEventListener('change', validateStep1);
    guidancePackage.addEventListener('change', validateStep1);

    emailInput.addEventListener('input', validateStep3);
    phoneInput.addEventListener('input', validateStep3);

    nextBtnStep1.addEventListener('click', function () {
        step1.style.display = 'none';
        step2.style.display = 'block';
    });

    nextBtnStep2.addEventListener('click', function () {
        step2.style.display = 'none';
        step3.style.display = 'block';
        validateStep3(); // Validate step 3 fields
    });

    document.querySelectorAll('.previous-btn').forEach(button => {
        button.addEventListener('click', function () {
            if (step2.style.display === 'block') {
                step2.style.display = 'none';
                step1.style.display = 'block';
            } else if (step3.style.display === 'block') {
                step3.style.display = 'none';
                step2.style.display = 'block';
            }
        });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        // Handle form submission logic here
        alert('Form submitted successfully!');
    });
});

</script>

    <style>
        /* Style for the disabled Next button */
        #next-btn[disabled] {
            background-color: #ccc; /* Gray color */
            color: #666; /* Text color */
            cursor: not-allowed; /* Change cursor */
        }
    </style>
</section>
