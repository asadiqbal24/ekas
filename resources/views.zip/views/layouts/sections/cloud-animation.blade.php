<div class="landing">
    <div class="mountain-scene">
        <div id="clouds">
            <div class="cloud"></div>
            <div class="cloud"></div>
            <div class="cloud"></div>
            <div class="cloud"></div>
            <div class="cloud"></div>
        </div>
        <!-- background mountains -->
        <div class="small-mountains">
            <div class="tri"></div>
            <div class="tri"></div>
            <div class="tri"></div>
        </div>
        <div class="tall-mountains">
            <div class="tri2"></div>
            <div class="tri2"></div>
            <div class="tri2"></div>
        </div>
        <!-- foreground mountains -->
        <div class="tiny-mountains">
            <div class="tri3"></div>
            <div class="tri3"></div>
            <div class="tri3"></div>
            <div class="tri3"></div>
            <div class="tri3"></div>
        </div>
    </div>
    <div class="ground"></div>
</div>