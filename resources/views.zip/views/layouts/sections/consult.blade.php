<section class="oks-consult-service">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-12" data-aos="fade-right" data-aos-duration="1200">
                <div class="oks-consult-serv-wrap">
                    <h2>Education Counselling <span>Services</span></h2>
                    <h5>Our expert counsellors can help transform your dreams into a reality by guiding you through the complexities of European course selection. Get personalised advice and insights tailored to your needs.</h5>
                    <a href="/services">Read More</a>
                </div>
            </div>
            <div class="col-sm-6">
                <!-- <div class="oks-cosult-image"> -->
                    <!-- <img src="http://localhost/BlogsPakistan/wp-content/uploads/2023/12/slide1-001x.png"> -->
                <!-- </div> -->
            </div>
        </div>
    </div>
</section>