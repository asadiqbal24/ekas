<section class="oks-blogs-section" data-aos="fade-up" data-aos-duration="1200" id="stories">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="oks-blogs-content">
                    <h2>Watch Their Stories</h2>
                </div>
            </div>
        </div>
        <div class="oks-blog-video owl-carousel">
            <div class="oks-blogs-item">
                <img src="image/blog-1.jpeg">
            </div>
            <div class="oks-blogs-item">
                <img src="image/blog-2.jpeg">
            </div>
            <div class="oks-blogs-item">
                <img src="image/blog-3.jpeg">
            </div>
        </div>
    </div>
</section>