<!-- EasyGuide section -->
<section class="oks-easyguide-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12" data-aos="fade-left" data-aos-duration="1200">
            </div>
            <div class="col-lg-6 col-md-12" data-aos="fade-left" data-aos-duration="1200">
                <div class="oks-easyguide-content">
                    <h2>Why ekas?</h2>
                    <p>Unlock Your Academic Journey with ekas: Your Centralized Hub for Expert Course Selection, Study Visa Guidance, and Comprehensive Academic Guides. Navigate your educational journey confidently with our holistic support, providing a centralized center for academic information and personalized guidance, ensuring a seamless transition towards your goal</p>
                    <a href="/about">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section>