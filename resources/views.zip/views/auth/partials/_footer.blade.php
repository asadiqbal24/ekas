<footer class="oks-site-footer oks-login-footer">
    <div class="container">
        <div class="row footer-bottom">
            <div class="col-sm-12">
                <div class="social-button">
                    <ul>
                        <li><a href="https://twitter.com/TheOfficialEkas" target="_blank"><object
                            type="image/svg+xml" data="image/x-twitter.svg"></object></a></li>
                <li><a href="https://www.instagram.com/theofficialekas?igsh=MWl5ZDRjYTFqNzU2bQ=="
                        target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                <li><a href="https://www.facebook.com/profile.php?id=61553192048665"><i
                            class="fa-brands fa-facebook" target="_blank"></i></a></li>
                <li><a href="https://www.youtube.com/channel/UCWTC1VlAUgygEtFAAAK0QEQ"><i
                            class="fa-brands fa-youtube"></i></a></li>
                <li><a href="https://www.tiktok.com/@theofficialekas?_t=8kf4I7Av7AX&_r=1"
                        target="_blank"><i class="fa-brands fa-tiktok"></i></a></li>
                    </ul>
                </div>
                <div class="oks-copyright">
                    <p>© {{date('Y')}} ekas - All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>