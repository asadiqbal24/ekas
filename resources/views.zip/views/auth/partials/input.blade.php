{{-- <div class="form-group password-div">
    <label for="">Password <sup class="text-danger">*</sup></label>
    <input type="password" name="password" id="" value="{{ old('password') }}" required
        class="show-password">
    <i class="fa-solid fa-eye show-pass-eye-btn" style="cursor: pointer"></i>
    
</div> --}}
